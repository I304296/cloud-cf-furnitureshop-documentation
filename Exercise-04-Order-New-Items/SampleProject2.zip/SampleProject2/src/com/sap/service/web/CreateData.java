package com.sap.service.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;

import com.sap.service.model.OnPremiseProductData;

/**
 * Servlet implementation class CreateData
 */
@WebServlet("/CreateData")
public class CreateData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doAdd(request);
		PrintWriter out = response.getWriter();
		out.println("Record Inserted");				
	}

	private void doAdd(HttpServletRequest request) {
		EntityManager em = null;
		EntityManagerFactory emf = null;
		try {
			
			InitialContext ctx = new InitialContext();
	        DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");

	        Map<String, Object> properties = new HashMap<String, Object>();
	        properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);
			emf = Persistence.createEntityManagerFactory("SampleProject2", properties);
			em = emf.createEntityManager();
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			
			OnPremiseProductData opd1 = new OnPremiseProductData();
			opd1.setProductID("FR-3204562");
			opd1.setSUPPLIERID("SP-201230");
			opd1.setSUPPLIERNAME("Making.com");
			opd1.setDELIVERYDATE("10 Days");
			opd1.setDISCOUNT("10%");
			opd1.setPRICE("57.99");
			opd1.setSTOCK("50");
			
			OnPremiseProductData opd2 = new OnPremiseProductData();
			opd2.setProductID("FR-3204563");
			opd2.setSUPPLIERID("SP-201230");
			opd2.setSUPPLIERNAME("Making.com");
			opd2.setDELIVERYDATE("15 Days");
			opd2.setDISCOUNT("5%");
			opd2.setPRICE("157.99");
			opd2.setSTOCK("20");
			
			OnPremiseProductData opd3 = new OnPremiseProductData();
			opd3.setProductID("FR-3303237");
			opd3.setSUPPLIERID("SP-201230");
			opd3.setSUPPLIERNAME("Making.com");
			opd3.setDELIVERYDATE("10 Days");
			opd3.setDISCOUNT("15%");
			opd3.setPRICE("137.99");
			opd3.setSTOCK("10");
			
			OnPremiseProductData opd4 = new OnPremiseProductData();
			opd4.setProductID("FR-3106355");
			opd4.setSUPPLIERID("SP-201230");
			opd4.setSUPPLIERNAME("Making.com");
			opd4.setDELIVERYDATE("12 Days");
			opd4.setDISCOUNT("12%");
			opd4.setPRICE("250.00");
			opd4.setSTOCK("15");	
			
			OnPremiseProductData opd5 = new OnPremiseProductData();
			opd5.setProductID("FR-3204565");
			opd5.setSUPPLIERID("SP-201232");
			opd5.setSUPPLIERNAME("YoYoMaking.com");
			opd5.setDELIVERYDATE("7 Days");
			opd5.setDISCOUNT("10%");
			opd5.setPRICE("210.00");
			opd5.setSTOCK("12");	
			
			OnPremiseProductData opd6 = new OnPremiseProductData();
			opd6.setProductID("FR-3303235");
			opd6.setSUPPLIERID("SP-201256");
			opd6.setSUPPLIERNAME("TechMaking.com");
			opd6.setDELIVERYDATE("10 Days");
			opd6.setDISCOUNT("8%");
			opd6.setPRICE("300.00");
			opd6.setSTOCK("16");	
			
			OnPremiseProductData opd7 = new OnPremiseProductData();
			opd7.setProductID("FR-3106354");
			opd7.setSUPPLIERID("SP-201256");
			opd7.setSUPPLIERNAME("TechMaking.com");
			opd7.setDELIVERYDATE("15 Days");
			opd7.setDISCOUNT("18%");
			opd7.setPRICE("500.00");
			opd7.setSTOCK("20");			

			OnPremiseProductData opd8 = new OnPremiseProductData();
			opd8.setProductID("FR-3303234");
			opd8.setSUPPLIERID("SP-201999");
			opd8.setSUPPLIERNAME("FurniMart.com");
			opd8.setDELIVERYDATE("5 Days");
			opd8.setDISCOUNT("15%");
			opd8.setPRICE("150.00");
			opd8.setSTOCK("40");	
			
			
			em.persist(opd1);
			em.persist(opd2);
			em.persist(opd3);
			em.persist(opd4);
			em.persist(opd5);
			em.persist(opd6);
			em.persist(opd7);
			em.persist(opd8);
			
			transaction.commit();
		}
		catch (NamingException e) {
			System.out.println("Error");
            //throw new ServletException(e);
        }
		finally{
			if(em.isOpen())
					em.close();
			if(emf.isOpen())
					emf.close();
		}		
	}		
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
