package com.sap.service.model;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: OnPremiseProductData
 *
 */
@Entity

public class OnPremiseProductData implements Serializable {

	   
	@Id
	private String ProductID;
	private String SUPPLIERID;
	private String SUPPLIERNAME;
	private String PRICE;
	private String STOCK;
	private String DELIVERYDATE;
	private String DISCOUNT;
	private static final long serialVersionUID = 1L;

	public OnPremiseProductData() {
		super();
	}   
	public String getProductID() {
		return this.ProductID;
	}

	public void setProductID(String ProductID) {
		this.ProductID = ProductID;
	}   
	public String getSUPPLIERID() {
		return this.SUPPLIERID;
	}

	public void setSUPPLIERID(String SUPPLIERID) {
		this.SUPPLIERID = SUPPLIERID;
	}   
	public String getSUPPLIERNAME() {
		return this.SUPPLIERNAME;
	}

	public void setSUPPLIERNAME(String SUPPLIERNAME) {
		this.SUPPLIERNAME = SUPPLIERNAME;
	}   
	public String getPRICE() {
		return this.PRICE;
	}

	public void setPRICE(String PRICE) {
		this.PRICE = PRICE;
	}   
	public String getSTOCK() {
		return this.STOCK;
	}

	public void setSTOCK(String STOCK) {
		this.STOCK = STOCK;
	}   
	public String getDELIVERYDATE() {
		return this.DELIVERYDATE;
	}

	public void setDELIVERYDATE(String DELIVERYDATE) {
		this.DELIVERYDATE = DELIVERYDATE;
	}   
	public String getDISCOUNT() {
		return this.DISCOUNT;
	}

	public void setDISCOUNT(String DISCOUNT) {
		this.DISCOUNT = DISCOUNT;
	}
   
}
